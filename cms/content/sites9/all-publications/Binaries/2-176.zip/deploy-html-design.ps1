param (
    # Path to the html distributive
    [string]$remoteDrive = "\\saintjohn03.ams.dev\c$",

    [string]$targetPath = "inetpub\wwwroot\2.1.0_html-design",
    [string]$artifactsTargetPath = ".",
    [string]$artifactsFolderName = "dist",

    [string]$localDrive = "S",

    # User credentils that is used to mount shared drive
    [string]$username = "Administrator",

    [string]$password = "Tr1d10nDxa"
)

$cryptedPass = ConvertTo-SecureString $password -AsPlainText -Force;
$credentials = New-Object System.Management.Automation.PSCredential($username, $cryptedPass);

# Mount remote drive
New-PSDrive -Name $localDrive -PSProvider FileSystem -Root $remoteDrive -Credential $credentials;

Write-Host "Getting remote drive root..."
$driveRoot = (Get-PSDrive $localDrive).Root
Write-Host "Remote drive root is $driveRoot."

$targetUrl = "$driveRoot\$targetPath"

if (!(Test-Path $targetUrl))
{
    Write-Host "Target folder $targetUrl does not exist. Creating..."
    New-Item -ItemType "directory" -Path $targetUrl
    Write-Host "Target folder has been created."
}

if(Test-Path "$targetUrl\$artifactsFolderName"){
    Write-Host "Removing previous copy of $targetUrl\$artifactsFolderName..."
    Remove-Item -Path "$targetUrl\$artifactsFolderName" -Recurse
    Write-Host "Previous copy has been removed."
}

Write-Host "Copying artifacts to mounted folder $targetUrl..."
Copy-Item "$artifactsTargetPath\$artifactsFolderName" -Destination "$targetUrl\$artifactsFolderName" -Recurse
Write-Host "Artifacts has been copied to $targetUrl folder."