Whitelabel HTML Design
======================
These configuration files are used to build the SDL Digital Experience Accelerator HTML design directly from the CMS.

## Files
* `.bowerrc` - to indicate the **bower_components** need to go in the **src** directory
* `bower.json` - Bower install configuration with dependencies like Bootstrap and jQuery
* `Gruntfile.js` - Grunt build configration
* `package.json` - npm install configuration with Grunt modules
* `README.md` - this file

